#!/usr/bin/env python2

sval = "42"
ival = 666

def myfunc():
    return "sval='%s'\nival=%d" %(sval,ival)

