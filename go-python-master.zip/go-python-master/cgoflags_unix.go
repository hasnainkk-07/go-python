// +build !windows

package python

// #cgo pkg-config: python-2.7
// #include "go-python.h"
import "C"
